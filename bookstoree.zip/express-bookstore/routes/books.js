
const express = require('express');
const router = express.Router();
const Joi = require('joi');

// Define the book schema
const bookSchema = Joi.object({
    isbn: Joi.string().length(13).required(),
    amazon_url: Joi.string().uri().required(),
    author: Joi.string().required(),
    language: Joi.string().required(),
    pages: Joi.number().integer().min(1).required(),
    publisher: Joi.string().required(),
    title: Joi.string().required(),
    year: Joi.number().integer().min(1000).max(9999).required()
});

// GET /books
router.get('/', async (req, res) => {
    // Implementation for getting all books
    res.send('Get all books');
});

// POST /books
router.post('/', async (req, res) => {
    try {
        const { error, value } = bookSchema.validate(req.body);
        if (error) {
            return res.status(400).json({ error: error.details.map(detail => detail.message) });
        }

        // Proceed with creating the book
        const newBook = value; // Replace this with actual creation logic
        res.status(201).json(newBook);
    } catch (err) {
        res.status(500).json({ error: "Internal Server Error" });
    }
});

// GET /books/:isbn
router.get('/:isbn', async (req, res) => {
    // Implementation for getting a book by ISBN
    res.send('Get a book by ISBN');
});

// PUT /books/:isbn
router.put('/:isbn', async (req, res) => {
    try {
        const { error, value } = bookSchema.validate(req.body);
        if (error) {
            return res.status(400).json({ error: error.details.map(detail => detail.message) });
        }

        // Proceed with updating the book
        const updatedBook = value; // Replace this with actual update logic
        res.json(updatedBook);
    } catch (err) {
        res.status(500).json({ error: "Internal Server Error" });
    }
});

// DELETE /books/:isbn
router.delete('/:isbn', async (req, res) => {
    // Implementation for deleting a book by ISBN
    res.send('Book deleted');
});

module.exports = router;
