
const request = require('supertest');
const app = require('../app'); // Import your Express app

// Set NODE_ENV to "test"
process.env.NODE_ENV = 'test';

describe('Books API', () => {

    it('should create a book with valid data', async () => {
        const newBook = {
            isbn: "1234567890123",
            amazon_url: "http://a.co/eobPtX2",
            author: "Test Author",
            language: "English",
            pages: 123,
            publisher: "Test Publisher",
            title: "Test Title",
            year: 2023
        };

        const response = await request(app)
            .post('/books')
            .send(newBook);

        expect(response.statusCode).toBe(201);
        expect(response.body).toHaveProperty('isbn', newBook.isbn);
    });

    it('should not create a book with invalid data', async () => {
        const invalidBook = {
            isbn: "123", // Invalid ISBN
            amazon_url: "invalid-url", // Invalid URL
            author: "Test Author",
            language: "English",
            pages: -123, // Invalid number of pages
            publisher: "Test Publisher",
            title: "Test Title",
            year: 999 // Invalid year
        };

        const response = await request(app)
            .post('/books')
            .send(invalidBook);

        expect(response.statusCode).toBe(400);
        expect(response.body).toHaveProperty('error');
    });

    it('should get a book by ISBN', async () => {
        const response = await request(app)
            .get('/books/1234567890123');

        expect(response.statusCode).toBe(200);
        expect(response.body).toHaveProperty('isbn', '1234567890123');
    });

    it('should update a book with valid data', async () => {
        const updatedBook = {
            isbn: "1234567890123",
            amazon_url: "http://a.co/eobPtX2",
            author: "Updated Author",
            language: "English",
            pages: 150,
            publisher: "Updated Publisher",
            title: "Updated Title",
            year: 2024
        };

        const response = await request(app)
            .put('/books/1234567890123')
            .send(updatedBook);

        expect(response.statusCode).toBe(200);
        expect(response.body).toHaveProperty('author', 'Updated Author');
    });

    it('should delete a book by ISBN', async () => {
        const response = await request(app)
            .delete('/books/1234567890123');

        expect(response.statusCode).toBe(200);
        expect(response.body).toHaveProperty('message', 'Book deleted');
    });

});
